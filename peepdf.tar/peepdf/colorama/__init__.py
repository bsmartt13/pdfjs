from .initialise import init
from .ansi import Fore, Back, Style
from .ansitowin32 import AnsiToWin32

VERSION = '0.1.18'

